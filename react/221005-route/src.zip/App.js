import ReactRouter from './ReactRouter';

function App() {
  return (
    <div>
      <h1>App.js</h1>
      <ReactRouter />
    </div>
  );
}

export default App;
